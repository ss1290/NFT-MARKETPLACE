import React from 'react';

const MyProfile = ()=>(
    <div>
        <h1>Profile</h1>
    </div>
);

export default MyProfile;