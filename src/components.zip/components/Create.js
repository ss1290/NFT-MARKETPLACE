import React from 'react';
import WalletCard from './WalletCard'

const Create = ()=>(
    <div>
        {/* <h1>Create new Item</h1> */}
        
       <h2> <WalletCard/></h2>
    </div>
);

export default Create;