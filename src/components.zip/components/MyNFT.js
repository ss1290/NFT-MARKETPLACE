import React from "react";

const MyNFT = ()=>(
    <div>
       <h1>Your collection</h1>
    </div>
);

export default MyNFT;